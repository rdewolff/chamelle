package labo5;

import java.util.ArrayList;


/**
 * Simple implementation of the {@link AdjacencyMatrix} using ArrayLists.
 * @author Florian Poulin <i>(florian.poulin at heig-vd.ch)</i>
 */
public class ArrayListMatrix implements AdjacencyMatrix {

	// For outputs
	private final static String spacerStr = " ";
	private final static String newlineStr = "\n";
	
	/**
	 * Structure holding the content of the matrix
	 */
	private ArrayList<ArrayList<Double>> content;
	
	/**
	 * Default constructor. Builds a matrix of size 0.
	 */
	public ArrayListMatrix() {
		content = new ArrayList<ArrayList<Double>>();
	}
	
	/**
	 * Constructor. Initializes the content of the matrix to <code>0</code>.
	 */
	public ArrayListMatrix(int length) {
		
		// allocate memory for length * length integers and initialize to 0
		content = new ArrayList<ArrayList<Double>>(length);
		for (int i=0; i<length; i++) {
			ArrayList<Double> tmp = new ArrayList<Double>(length);
			for (int j=0; j<length; j++)
				tmp.add(j, 0.0);
			content.add(tmp);
		}
	}

	/* (non-Javadoc)
	 * @see AdjacencyMatrix#getLength()
	 */
	public int size() {
		return content.size();
	}
	
	/* (non-Javadoc)
	 * @see AdjacencyMatrix#get(int, int)
	 */
	public double get(int i, int j) {
		return content.get(i).get(j);
	}

	/* (non-Javadoc)
	 * @see AdjacencyMatrix#set(int, int, boolean)
	 */
	public void set(int i, int j, double edge) {
		content.get(i).set(j, edge);
	}
	
	/* (non-Javadoc)
	 * @see AdjacencyMatrix#addLast()
	 */
	public int addLast() {
		
		// Add new column
		for (ArrayList<Double> alb : content)
			alb.add(0.0);
		
		// Allocate and add new row
		ArrayList<Double> tmp = new ArrayList<Double>(content.size()+1);
		for (int i=0; i<content.size()+1; i++)
			tmp.add(0.0);
		content.add(tmp);
		
		return content.size();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		
		String out = new String();
		for (ArrayList<Double> alb : content) {
			for (Double isEdge : alb)
				out += isEdge + spacerStr;
			out += newlineStr;
		}
		return out;
	}

	/* (non-Javadoc)
	 * @see labo5.AdjacencyMatrix#getTransitionMatrix()
	 */
	public AdjacencyMatrix getTransitionMatrix() {
		
		AdjacencyMatrix tm = new ArrayListMatrix (size());
		
		// Normalize rows
		for (int i=0; i<tm.size(); i++) {
			double sumRow = 0.0;
			for (int j=0; j<tm.size(); j++)
				sumRow += get(i, j);
			if (sumRow > 0.0)
				for (int j=0; j<tm.size(); j++)
					tm.set(i, j, get(i, j) / sumRow);
		}
		return tm;
	}

	/**
	 * Unit test.
	 * @param args console args.
	 */
	public static void main (String[] args) {
		
		// Declare some stuff
		int size = 10;
		AdjacencyMatrix am = new ArrayListMatrix (size);
		
		// Output
		System.out.println("Empty matrix :");
		System.out.println(am);
		
		// Define some edges
		for (int i=0; i<size; i++)
			am.set(i, i, 1);
		
		// Output
		System.out.println("Diagonal matrix :");
		System.out.println(am);
		
		// Add a new element
		am.addLast();
		
		// Output
		System.out.println("Resized matrix :");
		System.out.println(am);
		
		// Define some edges on newly added element
		am.set(2, 9, 1);
		am.set(1, 10, 1);
		
		// Output
		System.out.println("Modified matrix :");
		System.out.println(am);
		System.out.println(am.getTransitionMatrix());
		
		// Create a default matrix
		AdjacencyMatrix def = new ArrayListMatrix ();
		def.addLast();
		def.addLast();
		
		// Output
		System.out.println("Default matrix :");
		System.out.println(def);
	}
}
