
/*
 * cp_par.c 
 *
 * EIVD 2007 Programme réalisant un shell avec une copie parallèle
 * 
 * This file contains the core part of the cp_par program which performs a parallel
 * multi-threaded copy.
 *
 * Auteurs : <A compléter>
 */

#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define MSG_BUFFER_LEN 256 

#define PATH_PATTERN "%s/%s" 

#define FILE_MODE_ERROR_MSG "cannot find mode for file %s"
#define FILE_STAT_ERROR_MSG "cannot stat file %s"
#define UNKNOWN_FILE_MSG "file type for %s is unknown"
#define NOT_EXIST_MSG "cannot find file or directory %s"
#define USAGE_MSG "usage: %s <src> <dest>\n" 

int main_copy(const char *src_name, const char* dest_name); 

/* Possible file types to be considered for the copy */
#define FILE_STAT_ERROR_MSG "cannot stat file %s"
typedef enum _file_type { no_file, regular_file, directory_file, ignore_file, error_file } file_type; 

int numberOfCopies;   /* Total number of files which have been successfully copied */

/*
 * Returns the type of the file given in argument.
 * Must return one type from the enumeration _file_type
 */
file_type get_file_type(const char *path)
{
  struct stat file_stat;
  int status = 0;
  int l = strlen(path);
  
	/* Check if directory entries are "." or ".." */

  if (strcmp(&path[l-2], "/.") == 0)
    return ignore_file;
	
  if (strcmp(&path[l-3], "/..") == 0)
    return ignore_file;
	
  status = lstat(path, &file_stat);
	
  if (0 == status) {
    if (S_ISDIR(file_stat.st_mode))
      return directory_file;
    if (S_ISREG(file_stat.st_mode))
      return regular_file;
    return ignore_file;
  }
  
  /* If status < 0, then we check the reason; either there is */
  /* no file, or an error definitively occured */

  if (ENOENT == errno) {
    return no_file;
  } else {
    char msg_buffer[MSG_BUFFER_LEN];
    snprintf(msg_buffer, MSG_BUFFER_LEN, FILE_STAT_ERROR_MSG, path);
    perror(msg_buffer);
  }
  
  return error_file;
}


/* 
 * Copy a file from <src_name> to <dest_name> 
 * Returns 0 if everything is OK, -1 otherwise.
 *
 * Mode must be preserved! 
 */

int copy_file(const char *src_name, const char *dest_name) {

  /* Utiliser les fonctions de librairie fopen(), fread(), etc.*/

  /* A Compléter ... */
  
  /* LABO 2
  FILE fileSrc;
  FILE fileDest;
  
  fileSrc = fopen('r', *src_name);
    
  fileDest = fopen('w', "LAPIN.TXT");
  
  fwrite(*fileDest, "ADASJLD");
  
  fclose(fileDest);
  
  */
  

  numberOfCopies++;

  /* A Compléter ... */

  return 0; 
} 


/*
 * Do a copy of the directory pointed by src_dir_name to
 * the destination dest_dir_name.
 *
 * Mode must be preserved!
 */
int copy_directory(const char *src_dir_name, const char *dest_dir_name) {

  /* A compléter */

  return 0;
  
} 

/* Perform a main copy */
/* Returns 0 if everything is OK, -1 otherwise */
int main_copy(const char *src_name, const char *dest_name)
{
  file_type ft;
  
  if (!strcmp(src_name, dest_name)) {
    printf("<dest> identical to <src>\n");
    return -1;
  }
		
  ft = get_file_type(src_name);

  switch (ft) {
    case no_file:
      fprintf(stderr, NOT_EXIST_MSG, src_name);
      return -1;

    case regular_file:
      return copy_file(src_name, dest_name);

    case directory_file:
      return copy_directory(src_name, dest_name);

    case ignore_file:
    case error_file:
      return 0;

    default:
      fprintf(stderr, UNKNOWN_FILE_MSG, src_name);
      return -1; 
  }

} 

/* 
 * Entry point of this file.
 * Returns the number of files which have been successfully copied.
 */
int cp_par(int argc, char **argv) {

  if (argc != 3) {
    fprintf(stderr,USAGE_MSG,argv[0]);
    return 0 ;
  } 

  numberOfCopies = 0;

  if (main_copy(argv[1],argv[2]) == -1) {
    printf("main copy failed!\n");
    return -1;
  } else
    return numberOfCopies; 
}
