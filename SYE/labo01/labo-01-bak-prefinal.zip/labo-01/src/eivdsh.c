
/*
 * eivdsh.c 
 *
 * EIVD 2004 Programme réalisant un shell avec une copie parallèle
 * 
 * This file contains the main entry point of the program. It starts a shell and
 * processes the command lines entered by the end-user.
 * 
 * Auteurs : <A compléter>
 */


#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <assert.h>

void start_eivdsh(); /* Main shell */
int cp_par(int argc, char **argv);  /* Main function to perform parallel copy */

/* 
 * Start a new process 
 */
int doExec(int argc, char *args[]) {

  /* Fonction à modifier...  maj*/
 int status;  
 int ChildPid; 
 ChildPid = fork();      
 waitpid(ChildPid, 0, 0);

 if (ChildPid == 0) {
   status = execvp(args[0], args);
 }
 
 if (status == -1) {
   perror("execvp");
   printf("%s: exec failed.\n", args[0]);
   return -1;
 }
 
 return 0;
 
}

/*
 * Execute the FTP command
 * <serverMode> is 1 if the "eftpd" (server) command has been entered, or 0 if eftp (client) has been entered.
 * Returns -1 if an error occured.
 */
int doCp(int argc, char *args[]) {

  int status;
  int clientToServerPipe[2];
		
  status = pipe(clientToServerPipe);

  if (status != 0) {
    perror("Pipe open: failed\n");
    return -1;
  }

  /* 
    A compléter -- Appel à cp_par() 
    - Utilisation du tube déclaré pour la communication entre le parent et le fils
    - Ne pas oublier d'utiliser l'appel système waitpid() pour éviter un processus "zombie"
    - Retourner 0 si tout se passe bien, -1 s'il y a eu un problème
  */
  int copyDone; /* = -1; */
  int id;
  id = fork(); /* création du fils */
  if (id<0) { perror("Error fork"); exit(-1); }  
  
  if (id>0) {
    /* processus fils */
    close(clientToServerPipe[0]);
    copyDone = cp_par(argc, args);
    write(clientToServerPipe[1], &copyDone, 4);
    waitpid(id, NULL, 0);
    close(clientToServerPipe[1]);
    
    
  } else {
    /* processus parent */
    close(clientToServerPipe[1]);
    read(clientToServerPipe[0], &copyDone, 4);
    close(clientToServerPipe[0]);
  }
  /* retourne la valeur passée dans le tube */
  return copyDone;
 
 /* jamais atteint */
 return 0;
}


/*
 * Called when the user makes exit 
 */
int doExit(int argc, char *args[]) {

  if (argc == 1)
    exit(0);
  else if (argc == 2)
    exit(atoi(args[1]));
  else {
    printf("exit: Expression Syntax.\n");
    return -1;
  }

  return 0;  /* Never reached */
}

/* 
 * Entry point of the cp_par program 
 */
int main(int argc, char *argv[]) {

  printf("EIVD Shell with parallel copy.\n");

  start_eivdsh();  

  /*
   * Never reached ... 
   */

  exit(0);
}
