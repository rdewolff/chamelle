
/*
 * eivdsh_core.c 
 *
 * EIVD 2004 Programme r�alisant un shell avec une copie parall�le
 * 
 * This file contains the shell itself. It reads characters given by an end-user and
 * calls the appropriate functions.
 *
 * Auteurs : <A compl�ter>
 */

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define BUFFERSIZE	64
#define MAXARGSIZE	16
#define MAXARGS		  16

#define beep()		putchar(0x07)

int doExec(int argc, char *args[]);
int doCp(int argc, char *args[]);
int doExit(int argc, char *args[]);
void ctrlSignal(int sig);

/* 
 * Read a command line from the shell 
 */
void readline(char *s, int maxlength) {
  int i = 0;
  char c;

  while (1) {
    c = getchar();
    /*
     * if end of line, finish up 
     */
    if (c == '\n') {
      putchar('\n');
      s[i] = 0;
      return;
    }
    /*
     * else if backspace... 
     */
    else if ((c == '\b') || (c == 127)) {
      /*
       * if nothing to delete, beep 
       */
      if (i == 0)
        beep();

      /*
       * else delete it 
       */
      else {
	      printf("\b \b");
	      i--;
      }
    }
    /*
     * else if bad character or no room for more, beep 
     */
    else if (c < 0x20 || i + 1 == maxlength) {
      beep();
    }
    /*
     * else add the character 
     */
    else {
      s[i++] = c;
      putchar(c);
    }
  }
}


/**
 * tokenizeCommand
 *
 * Splits the specified command line into tokens, creating a token array with a maximum
 * of maxTokens entries, using storage to hold the tokens. The storage array should be as
 * long as the command line.
 *
 * Whitespace (spaces, tabs, newlines) separate tokens, unless
 * enclosed in double quotes. Any character can be quoted by preceeding
 * it with a backslash. Quotes must be terminated.
 *
 * Returns the number of tokens, or -1 on error.
 */
static int tokenizeCommand(char *command, int maxTokens, char *tokens[],
  char *storage) {

  const int quotingCharacter = 0x00000001;
  const int quotingString = 0x00000002;
  const int startedArg = 0x00000004;

  int state = 0;
  int numTokens = 0;

  char c;

  assert(maxTokens > 0);

  while ((c = *(command++)) != '\0') {
    if (state & quotingCharacter) {
      switch (c) {
      case 't': c = '\t';	break;
      case 'n':	c = '\n';	break;
      }
      *(storage++) = c;
      state &= ~quotingCharacter;
    } else if (state & quotingString) {
      switch (c) {
        case '\\':
	        state |= quotingCharacter; break;
        case '"':	state &= ~quotingString; break;
        default:
	        *(storage++) = c;
  	      break;
      }
    } else {
      switch (c) {
        case ' ':
        case '\t':
        case '\n':
          if (state & startedArg) {
	          *(storage++) = '\0';
            state &= ~startedArg;
          }
	        break;
        default:
	        if (!(state & startedArg)) {
	          if (numTokens == maxTokens) {
	            return -1;
	           }
	           tokens[numTokens++] = storage;
	           state |= startedArg;
	        }

	        switch (c) {
		        case '\\':
	  		      state |= quotingCharacter;
		      	  break;
		      	case '"':
     		      state |= quotingString;
              break;
	          default:
	            *(storage++) = c;
	            break;
  	      }
      }
    }
  }

  if (state & quotingCharacter) {
    printf("Unmatched \\.\n");
    return -1;
  }

  if (state & quotingString) {
    printf("Unmatched \".\n");
    return -1;
  }

  if (state & startedArg) {
    *(storage++) = '\0';
  }

  return numTokens;
}

/*
 * Execute the command read from the shell 
 */
void runline(char *line) {
  int argc, status;
  char args[BUFFERSIZE];
  char *argv[MAXARGS];

  readline(line, BUFFERSIZE);

  status = 0;
  argc = tokenizeCommand(line, MAXARGS, argv, args);
  argv[argc] = NULL;

  if (argc <= 0)
    return;

  if (argc > 0) {
    if (strcmp(argv[0], "exit") == 0) {     /* The user types "exit" */
      status = doExit(argc, argv);

      if (argc == 1)
	      status = 0;
      else if (argc == 2) 
	      status = atoi(argv[1]);
      else {
	      printf("exit: Expression Syntax.\n");
	      status = -1;
      }
    } else if (strcmp(argv[0], "cd") == 0) {

      /*
       * Perform CD command 
       */

      if (chdir(argv[1]) != 0) {     /* "cd" is changing the working directory; it's not an application */
    	  printf("cd failed.");
	      perror("cd");
      }
    } else if (strcmp(argv[0], "cp") == 0)
      status = doCp(argc, argv);     /* doCP() calls our special implementation of cp */
    else 
      status = doExec(argc, argv);   /* All the other commands ... */
  }
  if (status == -1)
    printf("command failed.\n");
}

/* detection des touche CTRL+C appuy�es */
void ctrlSignal(int sig) {
  if (sig == SIGINT) {
    printf("Veuillez utiliser la commande exit. \n");
    signal(sig, ctrlSignal); /* n�cessaire pour POSIX (r�cursivit� pour bon fonctionnement) */
  }
}

void start_eivdsh() {

 char prompt[] = "eivd_sh% ";

  char buffer[BUFFERSIZE];

  while (1) {
    /* Display a prompt as a convenient shell */
    printf("%s", prompt); 
    
    /* catch signal to avoid exit on CTRL+C */    
    signal(SIGINT, ctrlSignal);

    /* Read the command line and process it */
    runline(buffer);
  }
}
